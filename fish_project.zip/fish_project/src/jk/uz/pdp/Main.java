package jk.uz.pdp;

public class Main {

    public static void main(String[] args) {
        FishService.birthFish(null);
    }
}
