package jk.uz.pdp;

public enum Gender {
    MALE,
    FEMALE
}
